#!/usr/bin/env bash
set -e

PORT=9011
IMAGE=ctf-lab-11-15

# directory where this script lives
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[*] Building CTF Lab image from: $DIR/docker"
docker build -t "$IMAGE" "$DIR/docker"

echo "[*] Running on http://localhost:${PORT}"
docker rm -f "${IMAGE}-l11" >/dev/null 2>&1 || true
docker run --name "${IMAGE}-l11" -p "${PORT}:8000" "$IMAGE"

echo "[*] Open: http://localhost:${PORT}/level/11"